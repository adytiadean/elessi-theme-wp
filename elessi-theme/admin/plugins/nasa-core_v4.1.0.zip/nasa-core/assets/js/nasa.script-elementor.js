/**
 * Document nasa-core Elementor Preview ready
 */
jQuery(document).ready(function($) {
"use strict";

setInterval(function() {
    nasa_instagram_feed_init($);
    loading_slick_element($);
    loadingSlickVerticalCategories($);
    loadingSlickHasExtraVerticalNasaCore($);
    loadingSlickSliders_TitleNasaCore($);
    
    nasaRenderTagClouds($);
    loadCountDownNasaCore($);
    
    nasaLoadHeightFullWidthToSide($);
    
    nasa_init_select2($);
    
    $('body').trigger('nasa_init_pins_banners');
    $('body').trigger('nasa_init_metro_products');
    $('body').trigger('nasa_layout_metro_products');
    $('body').trigger('nasa_init_compare_images');
}, 2000);
/* =========== End Document nasa-core Elementor Preview ready ==================== */
});
